#!/usr/bin/env python3

import requests
import random,string,sys

OK, CORRUPT, MUMBLE, DOWN, CHECKER_ERROR = 101, 102, 103, 104, 110
SERVICENAME = "test_service_1"
PORT = 3003

def randstr(N=8):
    return ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(N))
def make_request(method, addr, team_addr, data=None):
    try:
        URL = addr.format(team_addr, PORT)
        r = method(URL, data=data) if data else method(URL)
        if r.status_code == 502:
            close(DOWN, "Service is down")
        if r.status_code != 200:
            r = method(URL, data=data) if data else method(URL)
            if r.status_code == 502:
                close(DOWN, "Service is down")
            if r.status_code != 200:
                close(MUMBLE, "Invalid HTTP response", "Invalid status code: {} {}".format(URL, r.status_code))	
    except Exception as ex:
        close(DOWN, "Service is down",ex)
    return r


def close(code, public="", private=""):
	if public:
		print(public)
	if private:
		print(private, file=sys.stderr)
	print('Exit with code {}'.format(code), file=sys.stderr)
	exit(code)

def info(*args):
    close(OK, "vulns: 1")

def check(*args):
    team_addr = args[0]
    r = make_request(requests.get, "http://{}:{}/check", team_addr)
    close(OK)

def put(*args):
    team_addr, flag_id, flag = args[:3]
    r = make_request(requests.post, "http://{}:{}/put", team_addr, {"flag_id":flag_id,"flag":flag})
    close(OK,flag_id)

def get(*args):
    argv = args
    if len(argv) < 3:
        print("Not enough args",len(argv),argv)
        quit()
    team_addr, flag_id, flag = argv[:3]
    r=make_request(requests.get, "http://{}:{}/get/"+flag_id, team_addr)
    resp_flag = r.text.rstrip()

    if flag == resp_flag:
        close(OK)
    close(CORRUPT, "Service corrupted", "Flag '{}' not in {}".format(flag, r.text))


def error_arg(*args):
    close(CHECKER_ERROR, private="Wrong command {}".format(sys.argv[1]))

COMMANDS = {
    'check': check, 
    'put': put, 
    'get': get, 
    'info': info
}

if __name__ == '__main__':
     open("log.txt","a").write(",".join(sys.argv)+"\n")
     try:
        COMMANDS.get(sys.argv[1], error_arg)(*sys.argv[2:])
     except Exception as ex:
        close(CHECKER_ERROR, private="INTERNAL ERROR: {}".format(ex))
