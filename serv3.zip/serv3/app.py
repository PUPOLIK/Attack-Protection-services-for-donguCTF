#!/usr/bin/env python3
from flask import Flask, request, render_template_string, jsonify, make_response
import os
import random
import string
import re
import json
from datetime import datetime

app = Flask(__name__)

if not os.path.exists('flags'):
    os.makedirs('flags')
if not os.path.exists('orders'):
    os.makedirs('orders')
if not os.path.exists('reviews'):
    os.makedirs('reviews')

# ========== ЭНДПОИНТЫ ДЛЯ ЧЕКЕРА ==========

@app.route('/check', methods=['GET'])
def check():
    return 'OK', 200

@app.route('/put', methods=['POST'])
def put():
    if request.is_json:
        data = request.get_json()
        flag_id = data.get('flag_id')
        flag = data.get('flag')
    else:
        flag_id = request.form.get('flag_id')
        flag = request.form.get('flag')
    
    if not flag_id or not flag:
        return 'Missing flag_id or flag', 400
    
    with open(f'flags/{flag_id}.txt', 'w') as f:
        f.write(flag)
    
    return flag_id, 200

@app.route('/get/<flag_id>', methods=['GET'])
def get(flag_id):
    try:
        with open(f'flags/{flag_id}.txt', 'r') as f:
            flag = f.read().strip()
        return flag, 200
    except FileNotFoundError:
        return 'Flag not found', 404

# ========== ОСНОВНОЙ МАГАЗИН ==========
BOUQUETS = [
    {
        'id': 1,
        'name': 'Нежность роз',
        'description': '25 алых роз в красной упаковке',
        'price': 3500,
        'image_url': 'https://ir.ozone.ru/s3/multimedia-5/c1000/6688779773.jpg'
    },
    {
        'id': 2,
        'name': 'Весеннее настроение',
        'description': 'Микс тюльпанов (желтые, красные, розовые)',
        'price': 2200,
        'image_url': 'https://storage.florist.ru/f/get/supplier/47/products/0/c9/4b/_ab31c0b2ef021126667a31124931/800x800/67c3009747ff3.jpg',
    },
    {
        'id': 3,
        'name': 'Солнечный день',
        'description': '15 подсолнухов с зеленью',
        'price': 2800,
        'image_url': 'https://main-cdn.sbermegamarket.ru/big1/hlr-system/144/619/735/321/216/29/100064404446b0.jpg',
    },
    {
        'id': 4,
        'name': 'Королевский букет',
        'description': '11 белых пионов и гортензия',
        'price': 4200,
        'image_url': 'https://cdn1.ozone.ru/s3/multimedia-1-v/7031988283.jpg',
    },
    {
        'id': 5,
        'name': 'Любимой маме',
        'description': '9 хризантем и альстромерии',
        'price': 1900,
        'image_url': 'https://content3.flowwow-images.com/data/flowers/1000x1000/32/1683709982_7678532.jpg',
    },
    {
        'id': 6,
        'name': 'Сказочный сон',
        'description': '7 розовых роз и лаванда',
        'price': 3100,
        'image_url': 'https://buket.market/upload/resize_cache/iblock/adf/4kjf62rliat6ujkber17uul9d1eqx32t/1000_1000_140cd750bba9870f18aada2478b24840a/IMG_0415.jpg',
    },
    {
        'id': 7,
        'name': 'Для принцессы',
        'description': 'Миниатюрный букет из 5 ранункулюсов',
        'price': 1600,
        'image_url': 'https://content2.flowwow-images.com/data/flowers/1000x1000/96/1677966166_70177396.jpg',
    },
    {
        'id': 8,
        'name': 'Феерия красок',
        'description': 'Сборный букет из 15 разных цветов',
        'price': 2700,
        'image_url': 'https://artflora.ru/sites/default/files/field/image/2023-04-10_09.16.08.jpg',
    },
    {
        'id': 9,
        'name': 'Волшебны кот даун',
        'description': 'У нее умный взгляд (КОТА ЗАПРЕЩЕННО УДАЛЯТЬ!!! ЕСЛИ ЕГО УДАЛЯТ СООБЩИТЕ АДМИНИСТРАТОРУ, НЕ ШУТКА)',
        'price': 3800,
        'image_url': 'https://sun9-37.userapi.com/s/v1/ig2/YifY5KrMZREws_bNNkaSvu8C9-XAQIWXVeGY33pznTzmuVFYKQE0wcKcqveV9D17qVMJTV-F-KDV7mWJwR_hEm9C.jpg?quality=95&as=32x27,48x41,72x61,108x92,160x136,240x204,360x306,480x408,540x459,640x544&from=bu&cs=640x0'
    }
]

def get_current_time():
    return datetime.now().strftime('%d.%m.%Y %H:%M')

def render_greeting(name):
    template = f'<h2>Спасибо за заказ, {name}!</h2><p>Ваш букет уже собирают</p><p>Данные карты: **** **** **** {random.randint(1000,9999)}</p>'
    return render_template_string(template)

@app.route('/')
def index():   
    reviews_html = ''
    if os.path.exists('reviews'):
        for filename in os.listdir('reviews'):
            if filename.endswith('.txt'):
                with open(f'reviews/{filename}', 'r', encoding='utf-8') as f:
                    review = json.loads(f.read())
                
                reviews_html += f'''
                <div class="review">
                    <div class="review-header">
                        <span class="review-author">{review['author']}</span>
                        <span class="review-date">{review['date']}</span>
                    </div>
                    <div class="review-content">
                        {review['text']}
                    </div>
                    <div class="review-rating">{'★' * review['rating']}{'☆' * (5-review['rating'])}</div>
                </div>
                '''

    catalog_html = ''
    for b in BOUQUETS:
        catalog_html += f'''
        <div class="bouquet-card">
            <div class="bouquet-image">
                <a href="{b['image_url']}" target="_blank">
                    <img src="{b['image_url']}" alt="{b['name']}" style="width: 100%; height: 100%; object-fit: cover;">
                </a>
            </div>
            <div class="bouquet-info">
                <h3>{b['name']}</h3>
                <p>{b['description']}</p>
                <div class="price">{b['price']} ₽</div>
                <button onclick="buy({b['id']})">Купить</button>
            </div>
        </div>
        '''
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Цветочный магазин "Весенний покой в нищите"</title>
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{
                font-family: 'Segoe UI', Arial, sans-serif;
                background: url('https://i.pinimg.com/originals/81/cf/8b/81cf8bf3bf1611589095b02361c79f26.jpg?nii=t') ;
                min-height: 100vh;
                padding: 20px;
            }}
            .container {{
                max-width: 1200px;
                margin: 0 auto;
                background: white;
                border-radius: 15px;
                box-shadow: 0 10px 40px rgba(0,0,0,0.2);
                overflow: hidden;
            }}
            .header {{
                background: #d44e6c;
                color: white;
                padding: 30px;
                text-align: center;
            }}
            .header h1 {{ font-size: 36px; margin-bottom: 10px; }}
            .header p {{ font-size: 18px; opacity: 0.9; }}
            .catalog {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 20px;
                padding: 20px;
            }}
            .bouquet-card {{
                background: white;
                border: 1px solid #ffcdd2;
                border-radius: 10px;
                overflow: hidden;
                transition: transform 0.3s, box-shadow 0.3s;
            }}
            .bouquet-card:hover {{
                transform: translateY(-5px);
                box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            }}
            .bouquet-image {{
                height: 200px;
                overflow: hidden;
                background: #fce4e4;
            }}
            .bouquet-image img {{
                width: 100%;
                height: 100%;
                object-fit: cover;
                transition: transform 0.3s;
            }}
            .bouquet-image img:hover {{
                transform: scale(1.05);
            }}
            .bouquet-info {{
                padding: 15px;
            }}
            .bouquet-info h3 {{
                color: #b33b56;
                margin-bottom: 10px;
            }}
            .bouquet-info p {{
                color: #666;
                font-size: 14px;
                margin-bottom: 10px;
            }}
            .price {{
                font-size: 20px;
                font-weight: bold;
                color: #d44e6c;
                margin: 10px 0;
            }}
            button {{
                background: #d44e6c;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                cursor: pointer;
                width: 100%;
                font-size: 16px;
                transition: background 0.3s;
            }}
            button:hover {{
                background: #b33b56;
            }}
            .modal {{
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.5);
                z-index: 1000;
            }}
            .modal-content {{
                background: white;
                width: 90%;
                max-width: 500px;
                margin: 50px auto;
                padding: 30px;
                border-radius: 10px;
                position: relative;
            }}
            .close {{
                position: absolute;
                top: 10px;
                right: 20px;
                font-size: 30px;
                cursor: pointer;
                color: #999;
            }}
            .close:hover {{
                color: #d44e6c;
            }}
            .form-group {{
                margin-bottom: 15px;
            }}
            .form-group label {{
                display: block;
                margin-bottom: 5px;
                color: #333;
                font-weight: 500;
            }}
            .form-group input,
            .form-group textarea,
            .form-group select {{
                width: 100%;
                padding: 10px;
                border: 1px solid #ddd;
                border-radius: 5px;
                font-size: 14px;
            }}
            .form-group input:focus,
            .form-group textarea:focus {{
                outline: none;
                border-color: #d44e6c;
            }}
            .form-group textarea {{
                min-height: 80px;
                resize: vertical;
            }}
            .card-row {{
                display: flex;
                gap: 10px;
            }}
            .card-row input {{
                flex: 1;
            }}
            .reviews-section {{
                padding: 20px;
                background: #f9f9f9;
                border-top: 1px solid #ffcdd2;
            }}
            .reviews-section h3 {{
                color: #b33b56;
                text-align: center;
                margin-bottom: 20px;
            }}
            .review {{
                background: white;
                border: 1px solid #ffcdd2;
                border-radius: 8px;
                padding: 15px;
                margin-bottom: 15px;
            }}
            .review-header {{
                display: flex;
                justify-content: space-between;
                margin-bottom: 10px;
                padding-bottom: 5px;
                border-bottom: 1px solid #ffcdd2;
            }}
            .review-author {{
                font-weight: bold;
                color: #d44e6c;
            }}
            .review-date {{
                color: #999;
                font-size: 12px;
            }}
            .review-content {{
                color: #333;
                margin-bottom: 10px;
                line-height: 1.5;
            }}
            .review-rating {{
                color: #ffc107;
            }}
            .add-review {{
                background: #fce4e4;
                padding: 20px;
                border-radius: 8px;
                margin-top: 20px;
            }}
            .add-review h4 {{
                color: #b33b56;
                margin-bottom: 15px;
            }}
            .footer {{
                background: #d44e6c;
                color: white;
                padding: 20px;
                text-align: center;
            }}
            .stats {{
                background: #fff0f3;
                padding: 10px;
                text-align: center;
                font-size: 12px;
                color: #b33b56;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>С 8 марта, дорогие женщины!</h1>
                <p>Дарите цветы, дарите радость!</p>
            </div>
            
            <div class="catalog">
                {catalog_html}
            </div>
            
            <div class="reviews-section">
                <h3>Отзывы наших покупателей</h3>
                {reviews_html if reviews_html else '<p style="text-align: center; color: #999;">Пока нет отзывов. Будьте первым!</p>'}
                
                <div class="add-review">
                    <h4>Оставить отзыв</h4>
                    <form method="POST" action="/review">
                        <div class="form-group">
                            <label>Ваше имя:</label>
                            <input type="text" name="name" required>
                        </div>
                        <div class="form-group">
                            <label>Оценка:</label>
                            <select name="rating">
                                <option value="5">5 - Отлично</option>
                                <option value="4">4 - Хорошо</option>
                                <option value="3">3 - Нормально</option>
                                <option value="2">2 - Плохо</option>
                                <option value="1">1 - Ужасно</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Ваш отзыв:</label>
                            <textarea name="text" placeholder="Напишите, что понравилось..." required></textarea>
                        </div>
                        <button type="submit">Отправить отзыв</button>
                    </form>
                </div>
            </div>
            
            <div class="stats">
                <strong>Статистика:</strong> Заказов: {len(os.listdir('orders')) if os.path.exists('orders') else 0} | Отзывов: {len(os.listdir('reviews')) if os.path.exists('reviews') else 0}
            </div>
            
        </div>
        
        <div id="orderModal" class="modal">
            <div class="modal-content">
                <span class="close" onclick="closeModal()">&times;</span>
                <h2 style="color: #b33b56; margin-bottom: 20px;">Оформление заказа</h2>
                <form method="POST" action="/order" id="orderForm">
                    <input type="hidden" name="bouquet_id" id="bouquet_id">
                    <div class="form-group">
                        <label>Ваше имя:</label>
                        <input type="text" name="name" placeholder="Имя получателя" required>
                    </div>
                    <div class="form-group">
                        <label>Email:</label>
                        <input type="email" name="email" placeholder="example@mail.ru" required>
                    </div>
                    <div class="form-group">
                        <label>Телефон:</label>
                        <input type="text" name="phone" placeholder="+7 (949) 123-45-67" required>
                    </div>
                    <div class="form-group">
                        <label>Адрес доставки:</label>
                        <input type="text" name="address" placeholder="Улица, дом, квартира" required>
                    </div>
                    <div class="form-group">
                        <label>Номер карты:</label>
                        <input type="text" name="card" placeholder="1234 5678 9012 3456" required>
                    </div>
                    <div class="card-row">
                        <div class="form-group">
                            <label>Срок действия:</label>
                            <input type="text" name="expiry" placeholder="MM/ГГ" required>
                        </div>
                        <div class="form-group">
                            <label>CVV:</label>
                            <input type="text" name="cvv" placeholder="123" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Пожелания к заказу:</label>
                        <textarea name="notes" placeholder="Напишите, что хотите добавить к букету..."></textarea>
                    </div>
                    <button type="submit">Оплатить заказ</button>
                </form>
            </div>
        </div>
        
        <script>
            function buy(id) {{
                document.getElementById('bouquet_id').value = id;
                document.getElementById('orderModal').style.display = 'block';
            }}
            
            function closeModal() {{
                document.getElementById('orderModal').style.display = 'none';
            }}
            
            window.onclick = function(event) {{
                if (event.target == document.getElementById('orderModal')) {{
                    closeModal();
                }}
            }}
        </script>
    </body>
    </html>
    '''

@app.route('/order', methods=['POST'])
def order():
    bouquet_id = request.form.get('bouquet_id')
    name = request.form.get('name')
    email = request.form.get('email')
    phone = request.form.get('phone')
    address = request.form.get('address')
    card = request.form.get('card')
    expiry = request.form.get('expiry')
    cvv = request.form.get('cvv')
    notes = request.form.get('notes')
    
    order_data = {
        'bouquet': bouquet_id,
        'name': name,
        'email': email,
        'phone': phone,
        'address': address,
        'card_last4': card[-4:] if card and len(card) >= 4 else '****',
        'expiry': expiry,
        'notes': notes,
        'time': get_current_time()
    }
    
    order_id = 'order_' + ''.join(random.choices(string.digits, k=8))
    with open(f'orders/{order_id}.json', 'w', encoding='utf-8') as f:
        json.dump(order_data, f, ensure_ascii=False, indent=2)
    
    greeting = render_greeting(name)
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <meta http-equiv="refresh" content="3;url=/">
        <title>Заказ оформлен</title>
        <style>
            body {{ font-family: Arial; background: url('https://i.pinimg.com/originals/37/dc/67/37dc67e684221d3ac60aee22664a0de0.jpg')}}
            .message {{ background: white; border-radius: 10px; padding: 30px; max-width: 500px; margin: 0 auto; text-align: center; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }}
        </style>
    </head>
    <body>
        <div class="message">
            {greeting}
            <p>Номер заказа: {order_id}</p>
            <p>Спасибо за покупку! Через 3 секунды вы вернетесь на главную.</p>
        </div>
    </body>
    </html>
    '''

@app.route('/review', methods=['POST'])
def review():
    name = request.form.get('name', '').strip()
    rating = request.form.get('rating', '5')
    text = request.form.get('text', '').strip()
    
    if not name or not text:
        return "Ошибка: заполните поля", 400

    clean_name = re.sub(r'[^a-zA-Z0-9_-]', '', name)
    if not clean_name:
        clean_name = 'anon_' + ''.join(random.choices(string.digits, k=4))
    
    review_data = {
        'author': name,
        'rating': int(rating),
        'text': text,
        'date': get_current_time()
    }
    
    review_id = clean_name + '_' + ''.join(random.choices(string.digits, k=4))
    with open(f'reviews/{review_id}.txt', 'w', encoding='utf-8') as f:
        f.write(json.dumps(review_data, ensure_ascii=False))
    
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <meta http-equiv="refresh" content="2;url=/">
        <title>Спасибо за отзыв</title>
        <style>
            body { font-family: Arial; background: url('https://i.pinimg.com/originals/37/dc/67/37dc67e684221d3ac60aee22664a0de0.jpg')}
            .message { background: white; border-radius: 10px; padding: 30px; max-width: 400px; margin: 0 auto; text-align: center; }
        </style>
    </head>
    <body>
        <div class="message">
            <h2>Спасибо за отзыв!</h2>
            <p>Через 2 секунды вы вернетесь на главную</p>
        </div>
    </body>
    </html>
    '''

@app.route('/debug')
def debug():
    return jsonify({
        'flags': len(os.listdir('flags')) if os.path.exists('flags') else 0,
        'orders': len(os.listdir('orders')) if os.path.exists('orders') else 0,
        'reviews': len(os.listdir('reviews')) if os.path.exists('reviews') else 0,
        'status': 'ok'
    })

if __name__ == '__main__':
    port = 3003
    print(f"[*] Запуск цветочного магазина на порту {port}")
    print("[*] Эндпоинты:")
    print("    /check - проверка")
    print("    /put   - сохранение флага")
    print("    /get/ID - получение флага")
    print("    /      - главная страница магазина")
    print("    /order - оформление заказа")
    print("    /review - отзывы")
    print("\nУЯЗВИМОСТИ, вообще этого не должно быть, но я захотел добавить:")
    print("    XSS в отзывах")
    print("    SSTI при заказе - в имени")
    app.run(host='0.0.0.0', port=port, debug=True)