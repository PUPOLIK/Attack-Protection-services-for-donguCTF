<?php
// config.php - настройки Google Sheets с сервисным аккаунтом
define('SPREADSHEET_ID', '');
define('API_KEY', '');
define('MAX_FILE_SIZE', 1024 * 1024); // 1 МБ
define('UPLOAD_DIR', 'uploads/');

//Данные сервисного аккаунта 
define('SERVICE_ACCOUNT_EMAIL', '');

// Правильно форматируем приватный ключ
$private_key = ""; //тут будет ваш api ключ


define('SERVICE_ACCOUNT_KEY', $private_key);

//Функция для получения access token
function getAccessToken() {
    $jwt_header = base64_encode(json_encode(['alg' => 'RS256', 'typ' => 'JWT']));
    
    $now = time();
    $jwt_claim = base64_encode(json_encode([
        'iss' => SERVICE_ACCOUNT_EMAIL,
        'scope' => '', //ваш токен аутент.
        'aud' => '', //ваш токен
        'exp' => $now + 3600,
        'iat' => $now
    ]));
    
    $jwt_header = rtrim(strtr($jwt_header, '+/', '-_'), '=');
    $jwt_claim = rtrim(strtr($jwt_claim, '+/', '-_'), '=');
    
    $signature = '';
    openssl_sign(
        $jwt_header . '.' . $jwt_claim,
        $signature,
        SERVICE_ACCOUNT_KEY,
        'sha256WithRSAEncryption'
    );
    
    $jwt_signature = rtrim(strtr(base64_encode($signature), '+/', '-_'), '=');
    $jwt = $jwt_header . '.' . $jwt_claim . '.' . $jwt_signature;
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, ''); //токен
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion' => $jwt
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code == 200) {
        $data = json_decode($response, true);
        return $data['access_token'] ?? '';
    }
    
    error_log("Failed to get access token: " . $response);
    return '';
}

//  Функция для чтения из Google Sheets
function getSheetData($sheet_name) {
    $token = getAccessToken();
    if (!$token) {
        return readLocalSheet($sheet_name);
    }
    
    $url = "" . SPREADSHEET_ID . "/values/" . urlencode($sheet_name); //ссылка на таблицу
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $token
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code == 200) {
        $data = json_decode($response, true);
        return $data['values'] ?? [];
    }
    
    return readLocalSheet($sheet_name);
}

//Функция для ЗАПИСИ в Google Sheets
function appendToSheet($sheet_name, $values) {
    $token = getAccessToken();
    if (!$token) {
        return saveLocalSheet($sheet_name, $values);
    }
    
    $url = "" . SPREADSHEET_ID . "/values/" . urlencode($sheet_name) . ":append?valueInputOption=USER_ENTERED"; //сссылка на таблицу
    
    $data = [
        'values' => [$values]
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $token,
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    // Сохраняем локально для бэкапа
    saveLocalSheet($sheet_name, $values);
    
    return $http_code == 200;
}

// Локальное сохранение (на всякий случай)
function saveLocalSheet($sheet_name, $values) {
    if (!file_exists('data')) {
        mkdir('data', 0777, true);
    }
    
    $file = "data/$sheet_name.json";
    $data = [];
    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true) ?? [];
    }
    $data[] = $values;
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    // Логируем
    if (!file_exists('logs')) mkdir('logs', 0777, true);
    $log_entry = date('Y-m-d H:i:s') . " | " . implode(" | ", $values) . "\n";
    file_put_contents("logs/$sheet_name.txt", $log_entry, FILE_APPEND);
    
    return true;
}

function readLocalSheet($sheet_name) {
    $file = "data/$sheet_name.json";
    if (file_exists($file)) {
        return json_decode(file_get_contents($file), true) ?? [];
    }
    return [];
}

// Проверка админа (Bigg_Owens)
function is_admin() {
    return isset($_SESSION['user']) && $_SESSION['user'] == 'Bigg_Owens';
}

// Получить данные пользователя
function getUserData($username) {
    $users = getSheetData('users');
    foreach ($users as $user) {
        if (isset($user[0]) && $user[0] == $username) {
            return [
                'username' => $user[0],
                'password' => $user[1],
                'role' => $user[2] ?? 'user'
            ];
        }
    }
    return null;
}

// Создаем папки
if (!file_exists('data')) mkdir('data', 0777, true);
if (!file_exists('logs')) mkdir('logs', 0777, true);
if (!file_exists(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0777, true);
?>