<?php
require_once 'config.php';

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if ($username && $password) {
        $users = getSheetData('users');
        $user_exists = false;
        foreach ($users as $user) {
            if (isset($user[0]) && strtolower($user[0]) == strtolower($username)) {
                $user_exists = true;
                break;
            }
        }
        
        if ($user_exists) {
            $message = "Пользователь '$username' уже существует";
            $message_type = 'error';
        } else {
            if (appendToSheet('users', [$username, $password, 'user'])) {
                $message = "Регистрация успешна";
                $message_type = 'success';
            } else {
                $message = "Ошибка регистрации";
                $message_type = 'error';
            }
        }
    } else {
        $message = "Заполните все поля";
        $message_type = 'error';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Регистрация</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('https://breeze.ru/files/images/1643105776_51-vsegda-pomnim-com-p-sakura-khram-foto-57.jpg') no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
        }
        .overlay {
            background: rgba(255, 255, 255, 0);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .header {
            background: #2c3e50;
            color: white;
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid #34495e;
        }
        .header h1 {
            margin: 0;
            font-size: 32px;
            font-weight: normal;
        }
        .nav {
            background: #34495e;
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #2c3e50;
        }
        .nav a {
            color: white;
            margin: 0 20px;
            text-decoration: none;
            font-size: 14px;
        }
        .nav a:hover {
            text-decoration: underline;
            color: #ecf0f1;
        }
        .container {
            max-width: 400px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border: 1px solid #ddd;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container h2 {
            margin: 0 0 20px;
            font-size: 24px;
            font-weight: normal;
            color: #2c3e50;
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-size: 14px;
        }
        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 3px;
            font-family: Arial, sans-serif;
            box-sizing: border-box;
        }
        input:focus {
            border-color: #2c3e50;
            outline: none;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #2c3e50;
            color: white;
            border: none;
            border-radius: 3px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background: #34495e;
        }
        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 3px;
            font-size: 14px;
        }
        .success {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        .error {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }
        .links {
            text-align: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        .links a {
            color: #2c3e50;
            text-decoration: none;
            font-size: 14px;
        }
        .links a:hover {
            text-decoration: underline;
        }
        
    </style>
</head>
<body>
    <div class="overlay">
        <div class="header">
            <h1>Регистрация</h1>
        </div>
        
        <div class="nav">
            <a href="/">Главная</a>
            <a href="/login.php">Вход</a>
            <a href="/register.php">Регистрация</a>
        </div>
        
        <div class="container">
            <h2>Создание аккаунта</h2>
            
            <?php if ($message): ?>
                <div class="message <?php echo $message_type; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label>Логин</label>
                    <input type="text" name="username" value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Пароль</label>
                    <input type="password" name="password" required>
                </div>
                
                <button type="submit">Зарегистрироваться</button>
            </form>
            
            <div class="links">
                <a href="/login.php">Уже есть аккаунт? Войти</a>
            </div>
        </div>
    </div>
</body>
</html>
