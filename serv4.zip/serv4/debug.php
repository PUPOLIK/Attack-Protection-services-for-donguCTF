<?php
session_start();
require_once 'config.php';

// ТОЛЬКО ДЛЯ Bigg_Owens!
if (!isset($_SESSION['user']) || $_SESSION['user'] !== 'Bigg_Owens') {
    header("HTTP/1.0 403 Forbidden");
    echo "Доступ запрещен";
    exit;
}

$users = getSheetData('users');
$flags = getSheetData('flags');
$uploads = file_exists('data/uploads.json') ? json_decode(file_get_contents('data/uploads.json'), true) : [];

// Сканируем загруженные файлы
$all_files = [];
if (file_exists('uploads')) {
    $users_dirs = scandir('uploads');
    foreach ($users_dirs as $dir) {
        if ($dir != '.' && $dir != '..' && is_dir('uploads/' . $dir)) {
            $files = scandir('uploads/' . $dir);
            foreach ($files as $file) {
                if ($file != '.' && $file != '..') {
                    $all_files[] = [
                        'user' => $dir,
                        'file' => $file,
                        'path' => 'uploads/' . $dir . '/' . $file
                    ];
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Админ-панель</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('https://backiee.com/static/wallpapers/1920x1080/299270.jpg') no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
        }
        .overlay {
            background: rgba(255, 255, 255, 0);
            min-height: 100vh;
            padding: 20px 0;
        }
        .header {
            background: #2c3e50;
            color: white;
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid #34495e;
            margin-bottom: 30px;
        }
        .header h1 {
            margin: 0;
            font-size: 32px;
            font-weight: normal;
        }
        .nav {
            background: #34495e;
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #2c3e50;
            margin-bottom: 30px;
        }
        .nav a {
            color: white;
            margin: 0 20px;
            text-decoration: none;
            font-size: 14px;
        }
        .nav a:hover {
            text-decoration: underline;
            color: #ecf0f1;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border: 1px solid #ddd;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container h2 {
            margin: 25px 0 15px;
            font-size: 22px;
            font-weight: normal;
            color: #2c3e50;
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 8px;
        }
        .container h2:first-of-type {
            margin-top: 0;
        }
        .warning {
            background: #fff3cd;
            border: 1px solid #ffeeba;
            color: #856404;
            padding: 15px;
            margin: 20px 0;
            border-radius: 3px;
            font-size: 14px;
        }
        .warning strong {
            font-weight: bold;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0 25px;
            font-size: 14px;
        }
        th {
            background: #2c3e50;
            color: white;
            padding: 12px 10px;
            text-align: left;
            font-weight: normal;
        }
        td {
            padding: 10px;
            border: 1px solid #ddd;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        tr:hover {
            background: #f5f5f5;
        }
        a {
            color: #2c3e50;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
            color: #34495e;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #2c3e50;
            font-size: 14px;
        }
        .back-link:hover {
            text-decoration: underline;
        }
        .admin-link {
            background: #f39c12;
            color: #2c3e50;
            padding: 5px 15px;
            border-radius: 3px;
            font-weight: bold;
        }
        .admin-link:hover {
            background: #e67e22;
            color: white;
        }
        .note {
            color: #666;
            font-size: 12px;
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="overlay">
        <div class="header">
            <h1>Админ-панель</h1>
        </div>
        
        <div class="nav">
            <a href="/">Главная</a>
            <a href="/cabinet.php">Кабинет</a>
            <a href="/login.php">Вход</a>
            <a href="/register.php">Регистрация</a>
            <a href="/debug.php" class="admin-link">Управление</a>
            <a href="/logout.php" style="float: right;">Выход</a>
        </div>
        
        <div class="container">
            <a href="/cabinet.php" class="back-link">← Вернуться в кабинет</a>
            
            <div class="warning">
                <strong>Внимание:</strong> Доступ только для Bigg_Owens
            </div>
            
            <h2>Пользователи (Google Sheets)</h2>
            <table>
                <tr>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Role</th>
                </tr>
                <?php if (!empty($users) && count($users) > 1): ?>
                    <?php foreach (array_slice($users, 1) as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user[0] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($user[1] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($user[2] ?? ''); ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3" style="text-align: center;">Нет данных</td>
                    </tr>
                <?php endif; ?>
            </table>
            
            <h2>Флаги</h2>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Flag</th>
                    <th>Date</th>
                </tr>
                <?php if (!empty($flags) && count($flags) > 1): ?>
                    <?php foreach (array_slice($flags, 1) as $flag): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($flag[0] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($flag[1] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($flag[2] ?? ''); ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3" style="text-align: center;">Нет флагов</td>
                    </tr>
                <?php endif; ?>
            </table>
            
            <h2>Загруженные файлы</h2>
            <?php if (!empty($all_files)): ?>
                <table>
                    <tr>
                        <th>Пользователь</th>
                        <th>Файл</th>
                        <th>Действие</th>
                    </tr>
                    <?php foreach ($all_files as $f): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($f['user']); ?></td>
                        <td><?php echo htmlspecialchars($f['file']); ?></td>
                        <td><a href="<?php echo $f['path']; ?>" target="_blank">Открыть</a></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            <?php else: ?>
                <p class="note" style="padding: 10px;">Нет загруженных файлов</p>
            <?php endif; ?>
            
            <h2>Системная информация</h2>
            <table>
                <tr>
                    <th style="width: 200px;">Параметр</th>
                    <th>Значение</th>
                </tr>
                <tr>
                    <td>Google Sheets ID</td>
                    <td><?php echo SPREADSHEET_ID; ?></td>
                </tr>
                <tr>
                    <td>API Key</td>
                    <td><?php echo substr(API_KEY, 0, 10); ?>...<?php echo substr(API_KEY, -5); ?></td>
                </tr>
                <tr>
                    <td>Папка загрузок</td>
                    <td><?php echo realpath(UPLOAD_DIR); ?></td>
                </tr>
                <tr>
                    <td>PHP Version</td>
                    <td><?php echo phpversion(); ?></td>
                </tr>
                <tr>
                    <td>Сервер</td>
                    <td><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'N/A'; ?></td>
                </tr>
            </table>
            
            <p class="note" style="margin-top: 20px;">Данные загружены из Google Sheets</p>
        </div>
    </div>
</body>
</html>