<?php
session_start();
require_once 'config.php';

$articles = getSheetData('articles');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Блог по Японии</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('https://avatars.mds.yandex.net/i?id=9d11b97dc67f9b93bf18f506dd9f01a8_l-5424908-images-thumbs&n=13' )/*https://docs.google.com/spreadsheets/d/e/2PACX-1vTzZNqUBsaytTJ2P2k10il82ypYOhj7O7eZQgz2E5Iqcp2brxfeWS6dzRLMWQoloMgjxBV4PdUHGu9U/pubhtml#gid=0 */ no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
        }
        .overlay {
            background: rgba(255, 255, 255, 0);
            min-height: 100vh;
        }
        .header {
            background: #2c3e50;
            color: white;
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid #34495e;
        }
        .header h1 {
            margin: 0;
            font-size: 32px;
            font-weight: normal;
        }
        .header p {
            margin: 10px 0 0;
            color: #bdc3c7;
        }
        .nav {
            background: #34495e;
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #2c3e50;
        }
        .nav a {
            color: white;
            margin: 0 20px;
            text-decoration: none;
            font-size: 14px;
        }
        .nav a:hover {
            text-decoration: underline;
            color: #ecf0f1;
        }
        .container {
            max-width: 800px;
            margin: 30px auto;
            background: white;
            padding: 25px;
            border: 1px solid #ddd;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container h2 {
            margin: 0 0 20px;
            font-size: 24px;
            font-weight: normal;
            color: #2c3e50;
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 10px;
        }
        .article {
            border-bottom: 1px solid #eee;
            padding: 20px 0;
        }
        .article:last-child {
            border-bottom: none;
        }
        .article h2 {
            margin: 0 0 10px;
            font-size: 20px;
            border: none;
            padding: 0;
        }
        .article h2 a {
            color: #2c3e50;
            text-decoration: none;
        }
        .article h2 a:hover {
            text-decoration: underline;
        }
        .article .date {
            color: #7f8c8d;
            font-size: 12px;
            margin-bottom: 10px;
        }
        .article p {
            margin: 0;
            line-height: 1.6;
            color: #333;
        }
        .admin-link {
            background: #f39c12;
            color: #2c3e50;
            padding: 3px 10px;
            border-radius: 3px;
            font-weight: bold;
        }
        .admin-link:hover {
            background: #e67e22;
            color: white;
        }
    </style>
</head>
<body>
    <div class="overlay">
        <div class="header">
            <h1>Блог по Японии</h1>
            <p>Я Лузя Какомкин и это мой блой! Присоединяйтесь и расскажите что знаете о Японии</p>
        </div>
        
        <div class="nav">
            <a href="/">Главная</a>
            <a href="/login.php">Вход</a>
            <a href="/register.php">Регистрация</a>
            <?php if (is_admin()): ?>
                <a href="/debug.php" class="admin-link">Управление</a>
            <?php endif; ?>
        </div>
        
        <div class="container">
            <h2>Последние записи</h2>
            
            <?php if (!empty($articles) && count($articles) > 1): ?>
                <?php foreach(array_slice($articles, 1) as $article): ?>
                    <div class="article">
                        <h2><?php echo htmlspecialchars($article[0] ?? 'Без названия'); ?></h2>
                        <div class="date"><?php echo date('d.m.Y'); ?></div>
                        <p><?php echo htmlspecialchars($article[1] ?? ''); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="article">
                    <h2>Первая запись</h2>
                    <div class="date">10.03.2026</div>
                    <p>Содержимое скоро появится...</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php
// Чекер эндпоинты
if ($_SERVER['REQUEST_URI'] == '/check') {
    echo "OK";
    exit;
}

if ($_SERVER['REQUEST_URI'] == '/put' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $flag_id = $_POST['flag_id'] ?? '';
    $flag = $_POST['flag'] ?? '';
    if ($flag_id && $flag) {
        appendToSheet('flags', [$flag_id, $flag, date('Y-m-d H:i:s')]);
        echo $flag_id;
        exit;
    }
}

if (strpos($_SERVER['REQUEST_URI'], '/get/') === 0) {
    $flag_id = substr($_SERVER['REQUEST_URI'], 5);
    $flags = getSheetData('flags');
    foreach ($flags as $f) {
        if (isset($f[0]) && $f[0] == $flag_id) {
            echo $f[1];
            exit;
        }
    }
    http_response_code(404);
    echo "Flag not found";
    exit;
}
?>