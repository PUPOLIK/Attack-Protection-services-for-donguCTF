<?php
session_start();
require_once 'config.php';

// Только для авторизованных
if (!isset($_SESSION['user'])) {
    header("Location: /login.php");
    exit;
}

$username = $_SESSION['user'];
$user_data = getUserData($username);

// Загрузка файла
$upload_message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['userfile'])) {
    $file = $_FILES['userfile'];
    
    if ($file['size'] > MAX_FILE_SIZE) {
        $upload_message = 'Ошибка: файл слишком большой (макс. 1 МБ)';
        $upload_message_type = 'error';
    } else {
        $upload_dir = UPLOAD_DIR . $username . '/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $filename = basename($file['name']);
        $upload_path = $upload_dir . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $upload_path)) {
            $upload_message = 'Файл загружен: ' . $filename;
            $upload_message_type = 'success';
            appendToSheet('uploads', [$username, $filename, date('Y-m-d H:i:s')]);
        } else {
            $upload_message = 'Ошибка загрузки';
            $upload_message_type = 'error';
        }
    }
}

// Сохранение био
$bio_message = '';
$bio_message_type = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['bio'])) {
    $bio = $_POST['bio'];
    file_put_contents("data/bio_{$username}.txt", $bio);
    $bio_message = 'Сохранено';
    $bio_message_type = 'success';
}

$bio = file_exists("data/bio_{$username}.txt") ? file_get_contents("data/bio_{$username}.txt") : '';

// Список файлов пользователя
$user_files = [];
$user_dir = UPLOAD_DIR . $username . '/';
if (file_exists($user_dir)) {
    $user_files = array_diff(scandir($user_dir), ['.', '..']);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Личный кабинет</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('https://images-travel.startsat60.com/holidays/1664250127740_mt-fuji-shutterstock-ha-limagelibrary.jpg?auto=compress&amp;w=1600&amp;fit=min') no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
        }
        .overlay {
            background: rgba(255, 255, 255, 0);
            min-height: 100vh;
            padding: 20px 0;
        }
        .header {
            background: #2c3e50;
            color: white;
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid #34495e;
            margin-bottom: 30px;
        }
        .header h1 {
            margin: 0;
            font-size: 32px;
            font-weight: normal;
        }
        .nav {
            background: #34495e;
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #2c3e50;
            margin-bottom: 30px;
        }
        .nav a {
            color: white;
            margin: 0 20px;
            text-decoration: none;
            font-size: 14px;
        }
        .nav a:hover {
            text-decoration: underline;
            color: #ecf0f1;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border: 1px solid #ddd;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container h2 {
            margin: 0 0 20px;
            font-size: 24px;
            font-weight: normal;
            color: #2c3e50;
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 10px;
        }
        .info-block {
            background: #f9f9f9;
            padding: 20px;
            margin-bottom: 25px;
            border: 1px solid #ddd;
            border-radius: 3px;
        }
        .info-block h3 {
            margin: 0 0 15px;
            font-size: 18px;
            font-weight: normal;
            color: #2c3e50;
        }
        .info-row {
            margin: 8px 0;
            font-size: 14px;
        }
        .label {
            font-weight: bold;
            display: inline-block;
            width: 80px;
            color: #555;
        }
        .upload-form {
            border: 2px dashed #ccc;
            padding: 25px;
            margin: 20px 0;
            text-align: center;
            background: #fafafa;
        }
        .upload-form h3 {
            margin: 0 0 15px;
            font-size: 18px;
            font-weight: normal;
            color: #2c3e50;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
            font-size: 14px;
        }
        input[type="text"],
        input[type="file"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 3px;
            font-family: Arial, sans-serif;
            font-size: 14px;
            box-sizing: border-box;
        }
        input[type="text"]:focus,
        textarea:focus {
            border-color: #2c3e50;
            outline: none;
        }
        textarea {
            min-height: 100px;
            resize: vertical;
        }
        button {
            background: #2c3e50;
            color: white;
            padding: 10px 25px;
            border: none;
            border-radius: 3px;
            font-size: 14px;
            cursor: pointer;
        }
        button:hover {
            background: #34495e;
        }
        .message {
            padding: 12px;
            margin: 15px 0;
            border-radius: 3px;
            font-size: 14px;
        }
        .success {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        .error {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }
        .files-list {
            margin-top: 25px;
        }
        .files-list h3 {
            margin: 0 0 15px;
            font-size: 18px;
            font-weight: normal;
            color: #2c3e50;
        }
        .file-item {
            padding: 10px;
            border-bottom: 1px solid #eee;
            font-size: 14px;
        }
        .file-item a {
            color: #2c3e50;
            text-decoration: none;
        }
        .file-item a:hover {
            text-decoration: underline;
            color: #34495e;
        }
        .admin-link {
            background: #f39c12;
            color: #2c3e50;
            padding: 5px 15px;
            border-radius: 3px;
            font-weight: bold;
        }
        .admin-link:hover {
            background: #e67e22;
            color: white;
        }
        .bio-content {
            background: white;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 3px;
            margin-bottom: 15px;
            min-height: 50px;
            font-size: 14px;
            line-height: 1.5;
        }
        .note {
            color: #666;
            font-size: 12px;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="overlay">
        <div class="header">
            <h1>Личный кабинет</h1>
        </div>
        
        <div class="nav">
            <a href="/">Главная</a>
            <a href="/cabinet.php">Кабинет</a>
            <a href="/login.php">Вход</a>
            <a href="/register.php">Регистрация</a>
            <?php if (is_admin()): ?>
                <a href="/debug.php" class="admin-link">Управление</a>
            <?php endif; ?>
            <a href="/logout.php" style="float: right;">Выход</a>
        </div>
        
        <div class="container">
            <h2>Информация об аккаунте</h2>
            
            <div class="info-block">
                <div class="info-row">
                    <span class="label">Логин:</span> <?php echo htmlspecialchars($user_data['username']); ?>
                </div>
                <div class="info-row">
                    <span class="label">Пароль:</span> <?php echo htmlspecialchars($user_data['password']); ?>
                </div>
                <div class="info-row">
                    <span class="label">Роль:</span> <?php echo htmlspecialchars($user_data['role']); ?>
                </div>
            </div>
            
            <!-- Раздел "О себе" -->
            <h2>О себе</h2>
            
            <div class="info-block">
                <?php if ($bio_message): ?>
                    <div class="message <?php echo $bio_message_type; ?>">
                        <?php echo $bio_message; ?>
                    </div>
                <?php endif; ?>
                
                <div class="bio-content">
                    <?php echo $bio; ?>
                </div>
                
                <form method="POST">
                    <div class="form-group">
                        <label>Текст</label>
                        <textarea name="bio" placeholder="Расскажите о себе..."><?php echo htmlspecialchars($bio); ?></textarea>
                    </div>
                    <button type="submit">Сохранить</button>
                </form>
            </div>
            
            <!-- Загрузка файлов -->
            <h2>Файлы</h2>
            
            <div class="info-block">
                <?php if ($upload_message): ?>
                    <div class="message <?php echo $upload_message_type; ?>">
                        <?php echo $upload_message; ?>
                    </div>
                <?php endif; ?>
                
                <div class="upload-form">
                    <h3>Загрузить новый файл</h3>
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="MAX_FILE_SIZE" value="<?php echo MAX_FILE_SIZE; ?>">
                        <div class="form-group">
                            <input type="file" name="userfile" required>
                        </div>
                        <button type="submit">Загрузить</button>
                    </form>
                    <p class="note">Максимальный размер: 1 МБ</p>
                </div>
                
                <?php if (!empty($user_files)): ?>
                    <div class="files-list">
                        <h3>Загруженные файлы</h3>
                        <?php foreach ($user_files as $file): ?>
                            <div class="file-item">
                                <a href="<?php echo UPLOAD_DIR . $username . '/' . $file; ?>" target="_blank"><?php echo $file; ?></a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="note" style="text-align: center;">Нет загруженных файлов</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>