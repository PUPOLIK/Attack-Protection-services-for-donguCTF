<?php
require_once 'config.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $flag_id = $_POST['flag_id'] ?? '';
    $flag = $_POST['flag'] ?? '';
    if ($flag_id && $flag) {
        appendToSheet('flags', [$flag_id, $flag, date('Y-m-d H:i:s')]);
        echo $flag_id;
        exit;
    }
}
http_response_code(400);
echo "Missing data";
?>