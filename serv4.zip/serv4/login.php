<?php
session_start();
require_once 'config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    $users = getSheetData('users');
    foreach ($users as $user) {
        if (isset($user[0]) && $user[0] == $username && isset($user[1]) && $user[1] == $password) {
            $_SESSION['user'] = $username;
            $_SESSION['role'] = $user[2] ?? 'user';
            
            header("Location: /cabinet.php");
            exit;
        }
    }
    $error = "Неверный логин или пароль";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Вход</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('https://static.visitjapan.ru/storage/app/media/Region/2889/image/gifu1353-6.jpeg') no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
        }
        .overlay {
            background: rgba(255, 255, 255, 0);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .header {
            background: #2c3e50;
            color: white;
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid #34495e;
        }
        .header h1 {
            margin: 0;
            font-size: 32px;
            font-weight: normal;
        }
        .nav {
            background: #34495e;
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #2c3e50;
        }
        .nav a {
            color: white;
            margin: 0 20px;
            text-decoration: none;
            font-size: 14px;
        }
        .nav a:hover {
            text-decoration: underline;
            color: #ecf0f1;
        }
        .container {
            max-width: 400px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border: 1px solid #ddd;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container h2 {
            margin: 0 0 20px;
            font-size: 24px;
            font-weight: normal;
            color: #2c3e50;
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-size: 14px;
        }
        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 3px;
            font-family: Arial, sans-serif;
            box-sizing: border-box;
        }
        input:focus {
            border-color: #2c3e50;
            outline: none;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #2c3e50;
            color: white;
            border: none;
            border-radius: 3px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background: #34495e;
        }
        .error {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 3px;
            font-size: 14px;
        }
        .links {
            text-align: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        .links a {
            color: #2c3e50;
            text-decoration: none;
            font-size: 14px;
        }
        .links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="overlay">
        <div class="header">
            <h1>Вход в систему</h1>
        </div>
        
        <div class="nav">
            <a href="/">Главная</a>
            <a href="/login.php">Вход</a>
            <a href="/register.php">Регистрация</a>
        </div>
        
        <div class="container">
            <h2>Авторизация</h2>
            
            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label>Логин</label>
                    <input type="text" name="username" required>
                </div>
                
                <div class="form-group">
                    <label>Пароль</label>
                    <input type="password" name="password" required>
                </div>
                
                <button type="submit">Войти</button>
            </form>
            
            <div class="links">
                <a href="/register.php">Нет аккаунта? Зарегистрироваться</a>
            </div>
        </div>
    </div>
</body>
</html>