<?php
require_once 'config.php';

$flag_id = $_GET['id'] ?? '';

if (!$flag_id) {
    http_response_code(400);
    echo "Missing flag_id";
    exit;
}

$flags = getSheetData('flags');
foreach ($flags as $f) {
    if (isset($f[0]) && $f[0] == $flag_id) {
        echo $f[1];
        exit;
    }
}

http_response_code(404);
echo "Flag not found";
?>