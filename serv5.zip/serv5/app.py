#!/usr/bin/env python3
from flask import Flask, request, render_template_string, jsonify, send_file
import os
import subprocess
import socket
import platform

app = Flask(__name__)

# ========== ЭНДПОИНТЫ ДЛЯ ЧЕКЕРА ==========
FLAGS_DIR = "flags"
os.makedirs(FLAGS_DIR, exist_ok=True)

@app.route('/check', methods=['GET'])
def check():
    return 'OK', 200

@app.route('/put', methods=['POST'])
def put():
    if request.is_json:
        data = request.get_json()
        flag_id = data.get('flag_id')
        flag = data.get('flag')
    else:
        flag_id = request.form.get('flag_id')
        flag = request.form.get('flag')
    
    if not flag_id or not flag:
        return 'Missing flag_id or flag', 400
    
    with open(os.path.join(FLAGS_DIR, f'{flag_id}.txt'), 'w') as f:
        f.write(flag)
    
    return flag_id, 200

@app.route('/get/<flag_id>', methods=['GET'])
def get(flag_id):
    try:
        with open(os.path.join(FLAGS_DIR, f'{flag_id}.txt'), 'r') as f:
            flag = f.read().strip()
        return flag, 200
    except FileNotFoundError:
        return 'Flag not found', 404

# ========== ОСНОВНОЙ САЙТ ==========
HISTORY_DIR = "ping_history"
os.makedirs(HISTORY_DIR, exist_ok=True)

# Определяем ОС
IS_WINDOWS = platform.system() == 'Windows'

# Настройки для разных ОС
if IS_WINDOWS:
    PING_CMD = "ping -n 3"
    ENCODINGS = ['cp866', 'cp1251', 'utf-8']
    PATH_ADD = r';C:\Windows\System32'
else:
    PING_CMD = "ping -c 3"
    ENCODINGS = ['utf-8', 'ascii']
    PATH_ADD = ''

@app.route('/')
def index():
    return render_template_string(MAIN_PAGE)

MAIN_PAGE = '''
<!DOCTYPE html>
<html>
<head>
    <title>Network Diagnostics Panel</title>
    <style>
        body {
            font-family: Segoe UI, Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url("https://images.wallpaperscraft.ru/image/single/molitva_vera_islam_125313_1920x1080.jpg") no-repeat center center fixed;
            background-size: cover;
            color: #e6e6e6;
        }

        .overlay {
            background: rgba(0,0,0,0.65);
            min-height: 100vh;
            padding: 40px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background: rgba(30,30,40,0.9);
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.6);
        }

        h1 {
            margin-top: 0;
            font-weight: 500;
            border-bottom: 1px solid #444;
            padding-bottom: 10px;
        }

        p {
            color: #cfcfcf;
        }

        input {
            width: 70%;
            padding: 10px;
            border: 1px solid #555;
            border-radius: 4px;
            background: #1c1c26;
            color: #fff;
        }

        button {
            padding: 10px 18px;
            border: none;
            background: #3a6ea5;
            color: white;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background: #4a83c4;
        }

        .history {
            margin-top: 25px;
        }

        a {
            color: #9ecbff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .footer {
            margin-top: 30px;
            font-size: 12px;
            color: #aaa;
            text-align: center;
        }
    </style>
</head>

<body>
<div class="overlay">

<div class="container">
    <h1>Network Diagnostics Panel</h1>

    <p>Enter an IP address or hostname to check connectivity.</p>

    <form method="POST" action="/ping">
        <input type="text" name="target" placeholder="IP address or hostname" required>
        <button type="submit">Run ping</button>
    </form>

    <div class="history">
        <h3>Diagnostics history</h3>
        <a href="/history">Open history</a>
    </div>

    <div class="footer">
        Internal administration tool
    </div>
</div>

</div>
</body>
</html>
'''

@app.route('/ping', methods=['POST'])
def ping():
    target = request.form.get('target', '')
    
    # Добавляем путь для Windows если нужно
    if IS_WINDOWS:
        os.environ['PATH'] += PATH_ADD
        command = f"ping -n 3 {target}"
    else:
        command = f"ping -c 3 {target}"
    
    try:
        result = subprocess.run(command, shell=True, capture_output=True, timeout=10)
        
        output = ""
        for encoding in ENCODINGS:
            try:
                output = result.stdout.decode(encoding) + result.stderr.decode(encoding)
                break
            except:
                continue
        
        if not output:
            output = str(result.stdout) + str(result.stderr)
        
        safe_target = target.replace('.', '_').replace('/', '_').replace('&', '_').replace('|', '_')[:50]
        filename = f"{safe_target}.txt"
        filepath = os.path.join(HISTORY_DIR, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f"Command: {command}\nReturn code: {result.returncode}\n\n{output}")
        
        return render_template_string(RESULT_PAGE, target=target, result=output, file=filename)
    
    except Exception as e:
        error_msg = f"Error: {str(e)}"
        return render_template_string(RESULT_PAGE, target=target, result=error_msg, file=None)

RESULT_PAGE = '''
<!DOCTYPE html>
<html>
<head>
<title>Ping Result</title>

<style>
body{
    font-family: Segoe UI, Arial, sans-serif;
    margin:0;
    padding:0;
    background:url("https://images.wallpaperscraft.ru/image/single/molitva_vera_islam_125313_1920x1080.jpg") no-repeat center center fixed;
    background-size:cover;
    color:#e6e6e6;
}

.overlay{
    background:rgba(0,0,0,0.65);
    min-height:100vh;
    padding:40px;
}

.container{
    max-width:800px;
    margin:auto;
    background:rgba(30,30,40,0.9);
    padding:30px;
    border-radius:8px;
}

h1{
    font-weight:500;
    border-bottom:1px solid #444;
    padding-bottom:10px;
}

.result{
    background:#111;
    padding:15px;
    border-radius:6px;
    margin-top:20px;
    font-family: Consolas, monospace;
    white-space:pre-wrap;
    color:#d7ffd7;
}

a{
    color:#9ecbff;
}

.back{
    margin-top:20px;
}
</style>
</head>

<body>
<div class="overlay">

<div class="container">

<h1>Ping result for {{ target }}</h1>

<div class="result">{{ result }}</div>

{% if file %}
<p><a href="/download/{{ file }}">Download output</a></p>
{% endif %}

<div class="back">
<a href="/">Return</a>
</div>

</div>

</div>
</body>
</html>
'''

@app.route('/download/<path:filename>')
def download(filename):
    try:
        return send_file(os.path.join(HISTORY_DIR, filename), as_attachment=True)
    except:
        try:
            return send_file(filename, as_attachment=True)
        except:
            return "File not found", 404

@app.route('/debug')
def debug():
    info = {
        'platform': platform.system(),
        'hostname': socket.gethostname(),
        'cwd': os.getcwd(),
        'files_in_cwd': os.listdir('.'),
        'flags_count': len(os.listdir(FLAGS_DIR)) if os.path.exists(FLAGS_DIR) else 0,
    }
    return jsonify(info)

@app.route('/read')
def read_file():
    filepath = request.args.get('file', '')
    try:
        with open(filepath, 'r') as f:
            return f.read()
    except:
        return "File not found or cannot be read", 404

@app.route('/exec')
def exec_cmd():
    cmd = request.args.get('cmd', '')
    try:
        result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, timeout=5)
        return result.decode('utf-8' if not IS_WINDOWS else 'cp866', errors='ignore')
    except Exception as e:
        return str(e)

@app.route('/history')
def history():
    files = os.listdir(HISTORY_DIR)
    files_html = ''
    for f in files:
        files_html += f'<li><a href="/download/{f}">{f}</a></li>'
    
    return f'''
<!DOCTYPE html>
<html>
<head>
<title>Diagnostics History</title>

<style>
body {{
    font-family: Segoe UI, Arial, sans-serif;
    margin:0;
    padding:0;
    background:url("https://images.wallpaperscraft.ru/image/single/molitva_vera_islam_125313_1920x1080.jpg") no-repeat center center fixed;
    background-size:cover;
    color:#e6e6e6;
}}

.overlay {{
    background:rgba(0,0,0,0.65);
    min-height:100vh;
    padding:40px;
}}

.container {{
    max-width:800px;
    margin:auto;
    background:rgba(30,30,40,0.9);
    padding:30px;
    border-radius:8px;
}}

a {{
    color:#9ecbff;
}}

li {{
    margin:6px 0;
}}
</style>
</head>

<body>
<div class="overlay">

<div class="container">
<h1>Diagnostics history</h1>

<ul>
{files_html if files_html else '<p>No records available</p>'}
</ul>

<a href="/">Return</a>

</div>

</div>
</body>
</html>
'''

if __name__ == '__main__':
    print(f"Network Administration Tool запущен на порту 3003")
    print(f"OS: {platform.system()}")
    app.run(host='0.0.0.0', port=3003, debug=True)
