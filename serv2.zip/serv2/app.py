#!/usr/bin/env python3
from flask import Flask, request, jsonify
import os
import random
import string
import re
import json
from datetime import datetime

app = Flask(__name__)

# Создаем папки
if not os.path.exists('flags'):
    os.makedirs('flags')
if not os.path.exists('posts'):
    os.makedirs('posts')

# ========== ЭНДПОИНТЫ ДЛЯ ЧЕКЕРА ==========

@app.route('/check', methods=['GET'])
def check():
    return 'OK', 200

@app.route('/put', methods=['POST'])
def put():
    if request.is_json:
        data = request.get_json()
        flag_id = data.get('flag_id')
        flag = data.get('flag')
    else:
        flag_id = request.form.get('flag_id')
        flag = request.form.get('flag')
    
    if not flag_id or not flag:
        return 'Missing flag_id or flag', 400
    
    with open(f'flags/{flag_id}.txt', 'w') as f:
        f.write(flag)
    
    return flag_id, 200

@app.route('/get/<flag_id>', methods=['GET'])
def get(flag_id):
    try:
        with open(f'flags/{flag_id}.txt', 'r') as f:
            flag = f.read().strip()
        return flag, 200
    except FileNotFoundError:
        return 'Flag not found', 404

# ========== ДОПОЛНИТЕЛЬНЫЕ ФУНКЦИИ ==========

@app.route('/read')
def read_file():
    """Читает файл"""
    path = request.args.get('path', '')
    if not path:
        return 'Укажите path параметр', 400
    
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        return content, 200
    except Exception as e:
        return str(e), 500

@app.route('/list')
def list_dir():
    """Показывает содержимое директории"""
    path = request.args.get('path', '.')
    
    try:
        files = os.listdir(path)
        result = []
        for f in files:
            full = os.path.join(path, f)
            is_dir = os.path.isdir(full)
            result.append({
                'name': f,
                'type': 'dir' if is_dir else 'file',
                'size': os.path.getsize(full) if not is_dir else 0
            })
        return jsonify(result)
    except Exception as e:
        return str(e), 500

# ========== ОСНОВНОЙ ФОРУМ ==========

def get_current_time():
    """Возвращает текущее время в формате ДД.ММ.ГГГГ ЧЧ:ММ"""
    return datetime.now().strftime('%d.%m.%Y %H:%M')

def save_post(username, message):
    """Сохраняет сообщение в файл пользователя"""
    
    if not username:
        username = 'anon_' + ''.join(random.choices(string.digits, k=4))
    
    filename = f'posts/{username}.txt'
    timestamp = get_current_time()
    entry = f'[{timestamp}] {message}\n'
    
    with open(filename, 'a', encoding='utf-8') as f:
        f.write(entry)
    
    return username

def get_all_posts():
    """Собирает все сообщения"""
    posts = []
    
    if os.path.exists('posts'):
        for filename in os.listdir('posts'):
            if filename.endswith('.txt'):
                username = filename[:-4]
                with open(f'posts/{filename}', 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                
                for line in lines:
                    line = line.strip()
                    if line:
                        if line.startswith('[') and ']' in line:
                            time_part = line[1:line.index(']')]
                            msg_part = line[line.index(']')+1:].strip()
                            posts.append({
                                'username': username,
                                'time': time_part,
                                'message': msg_part
                            })
                        else:
                            posts.append({
                                'username': username,
                                'time': '00.00.0000 00:00',
                                'message': line
                            })
    
    posts.sort(key=lambda x: x['time'], reverse=True)
    return posts

@app.route('/')
def index():
    """Главная страница форума"""
    
    posts = get_all_posts()
    
    posts_html = ''
    for post in posts:
        posts_html += '<div class="post">'
        posts_html += '<div class="post-header">'
        posts_html += '<span class="post-id">' + post['username'] + '</span>'
        posts_html += '<span class="post-date">' + post['time'] + '</span>'
        posts_html += '</div>'
        posts_html += '<div class="post-content">'
        posts_html += post['message']
        posts_html += '</div>'
        posts_html += '</div>'
    
    if not posts:
        posts_html = '<p style="color: #666; padding: 10px;">Нет сообщений. Будьте первым!</p>'
    
    html = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Форум / Сообщения</title>
        <style>
            body {{ 
                background-image: url('https://64.media.tumblr.com/10b6161cae7baa32395e40351205f4da/31d798f6f2dab6f4-e7/s2048x3072/a41ed07da698bc4b1b7259a224c3d6d8d0978b36.gifv');
                background-size: cover;
                background-position: center;
                background-attachment: fixed;
                background-repeat: no-repeat;
                font-family: Verdana, Arial, sans-serif; 
                font-size: 12px; 
                margin: 20px; 
                color: #000000; 
            }}
            .container {{ max-width: 900px; margin: 0 auto; background: rgba(255, 255, 255, 0.9); border: 1px solid #808080; padding: 15px; backdrop-filter: blur(5px); }}
            .header {{ background: #e0e0e0; padding: 10px; margin-bottom: 15px; border: 1px solid #c0c0c0; }}
            .header h1 {{ font-size: 18px; font-weight: bold; margin: 0; color: #333333; }}
            .header p {{ margin: 5px 0 0 0; color: #666666; }}
            .form-section {{ background: #f5f5f5; border: 1px solid #c0c0c0; padding: 10px; margin-bottom: 20px; }}
            .form-section h3 {{ font-size: 14px; margin: 0 0 10px 0; color: #333333; border-bottom: 1px solid #c0c0c0; padding-bottom: 5px; }}
            .form-group {{ margin-bottom: 10px; }}
            .form-group label {{ display: block; margin-bottom: 3px; font-weight: bold; }}
            .form-group input, .form-group textarea {{ width: 100%; padding: 5px; border: 1px solid #808080; background: #ffffff; font-family: 'Courier New', monospace; font-size: 12px; box-sizing: border-box; }}
            .form-group textarea {{ min-height: 80px; }}
            button {{ background: #e0e0e0; border: 1px solid #808080; padding: 5px 15px; font-size: 12px; cursor: pointer; }}
            button:hover {{ background: #c0c0c0; }}
            .posts-section {{ margin-top: 20px; }}
            .posts-section h3 {{ font-size: 14px; margin: 0 0 10px 0; color: #333333; border-bottom: 1px solid #c0c0c0; padding-bottom: 5px; }}
            .post {{ border: 1px solid #c0c0c0; margin-bottom: 10px; background: #fafafa; }}
            .post-header {{ background: #e8e8e8; padding: 5px 10px; border-bottom: 1px solid #c0c0c0; font-size: 11px; display: flex; justify-content: space-between; }}
            .post-id {{ font-weight: bold; color: #0066cc; }}
            .post-date {{ color: #666666; }}
            .post-content {{ padding: 10px; font-family: 'Courier New', monospace; white-space: pre-wrap; word-break: break-word; }}
            .footer {{ margin-top: 15px; padding-top: 10px; border-top: 1px solid #c0c0c0; font-size: 11px; color: #666666; text-align: center; }}
            .info {{ background: #ffffe0; border: 1px solid #c0c0c0; padding: 5px 10px; margin-bottom: 10px; font-size: 11px; }}
            .stats {{ background: #f0f0f0; padding: 5px 10px; border: 1px solid #c0c0c0; margin-top: 10px; font-size: 11px; }}
            a {{ color: #0000ee; }}
            a:visited {{ color: #551a8b; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Форум / Сообщения</h1>
                <p>Всего сообщений: {len(posts)}</p>
            </div>
            
            <div class="info">
                <strong>Информация:</strong> Сообщения сохраняются с указанием времени.
            </div>
            
            <div class="form-section">
                <h3>Добавить сообщение</h3>
                <form method="POST" action="/post">
                    <div class="form-group">
                        <label>Ваше имя:</label>
                        <input type="text" name="username" placeholder="например: Girsha" required>
                    </div>
                    <div class="form-group">
                        <label>Сообщение:</label>
                        <textarea name="message" placeholder="Текст сообщения..." required></textarea>
                    </div>
                    <button type="submit">Отправить</button>
                </form>
            </div>
            
            <div class="posts-section">
                <h3>Сообщения</h3>
                {posts_html}
            </div>
            
            <div class="stats">
                <strong>Статистика:</strong> Флагов: {len(os.listdir('flags')) if os.path.exists('flags') else 0} | Сообщений: {len(posts)}
            </div>
            
            <div class="footer">
                Форум / Сообщения 2.0
            </div>
        </div>
    </body>
    </html>
    '''
    
    return html

@app.route('/post', methods=['POST'])
def post():
    """Добавление сообщения"""
    username = request.form.get('username', '').strip()
    message = request.form.get('message', '').strip()
    
    if not username or not message:
        return "Ошибка: не заполнены поля", 400
    
    saved_username = save_post(username, message)
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <meta http-equiv="refresh" content="2;url=/">
        <title>Сообщение добавлено</title>
        <style>
            body {{ 
                background-image: url('https://64.media.tumblr.com/10b6161cae7baa32395e40351205f4da/31d798f6f2dab6f4-e7/s2048x3072/a41ed07da698bc4b1b7259a224c3d6d8d0978b36.gifv');
                background-size: cover;
                background-position: center;
                background-attachment: fixed;
                font-family: Verdana, Arial, sans-serif; 
                font-size: 12px; 
                margin: 50px; 
            }}
            .message {{ background: rgba(255, 255, 255, 0.9); border: 1px solid #808080; padding: 20px; max-width: 500px; margin: 0 auto; backdrop-filter: blur(5px); }}
        </style>
    </head>
    <body>
        <div class="message">
            <h2>Сообщение добавлено</h2>
            <p>От: {username}</p>
            <p>Время: {get_current_time()}</p>
            <p>Вы будете перенаправлены через 2 секунды...</p>
            <p><a href="/">Вернуться к сообщениям</a></p>
        </div>
    </body>
    </html>
    '''

@app.route('/debug')
def debug():
    """Информация о системе"""
    posts_count = 0
    if os.path.exists('posts'):
        for filename in os.listdir('posts'):
            if filename.endswith('.txt'):
                with open(f'posts/{filename}', 'r', encoding='utf-8') as f:
                    posts_count += len(f.readlines())
    
    return jsonify({
        'flags': len(os.listdir('flags')) if os.path.exists('flags') else 0,
        'users': len(os.listdir('posts')) if os.path.exists('posts') else 0,
        'messages': posts_count,
        'status': 'ok'
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3003, debug=True)