#!/usr/bin/env python3
from flask import Flask, request, render_template_string, jsonify
import os

app = Flask(__name__)

if not os.path.exists('flags'):
    os.makedirs('flags')

# ========== ДЛЯ ЧЕКЕРА ========================================

@app.route('/check', methods=['GET'])
def check():
    return 'OK', 200

@app.route('/put', methods=['POST'])
def put():
    if request.is_json:
        data = request.get_json()
        flag_id = data.get('flag_id')
        flag = data.get('flag')
    else:
        flag_id = request.form.get('flag_id')
        flag = request.form.get('flag')
    
    if not flag_id or not flag:
        return 'Missing flag_id or flag', 400
    with open(f'flags/{flag_id}.txt', 'w') as f:
        f.write(flag)
    
    return flag_id, 200

@app.route('/get/<flag_id>', methods=['GET'])
def get(flag_id):
    try:
        with open(f'flags/{flag_id}.txt', 'r') as f:
            flag = f.read().strip()
        return flag, 200
    except FileNotFoundError:
        return 'Flag not found', 404

#============================================================

#Ниже сервис:

@app.route('/')
def home():
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Arasaki</title>
        <style>
            * { 
                margin: 0; 
                padding: 0; 
                box-sizing: border-box; 
            }
            
            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
                background-image: url('https://avatars.mds.yandex.net/i?id=80c2a203e4bcd95e9ae1dc6a25ddca2e_l-8315541-images-thumbs&n=13');
                background-size: cover;
                background-position: center;
                background-attachment: fixed;
                background-repeat: no-repeat;
                min-height: 100vh;
                padding: 30px 20px;
                position: relative;
            }
            
            /* Полупрозрачный оверлей для читаемости */
            body::before {
                content: '';
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(255, 255, 255, 0.85);
                z-index: 0;
            }
            
            .container {
                max-width: 1100px;
                margin: 0 auto;
                background: white;
                border-radius: 12px;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
                overflow: hidden;
                position: relative;
                z-index: 1;
                border: 1px solid rgba(0,0,0,0.1);
            }
            
            .header {
                background: #1a2b3c;
                color: white;
                padding: 18px 30px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-bottom: 3px solid #ff6b35;
            }
            
            .logo {
                font-size: 26px;
                font-weight: 600;
                letter-spacing: 0.5px;
            }
            
            .logo span {
                color: #ff6b35;
                font-weight: 700;
            }
            
            .nav a {
                color: #e0e0e0;
                text-decoration: none;
                margin-left: 25px;
                padding: 6px 12px;
                border-radius: 6px;
                font-size: 15px;
                transition: all 0.2s;
            }
            
            .nav a:hover {
                background: #ff6b35;
                color: white;
            }
            
            .main {
                padding: 35px;
            }
            
            .hero {
                text-align: center;
                margin-bottom: 35px;
                padding-bottom: 20px;
                border-bottom: 2px dashed #ddd;
            }
            
            .hero h1 {
                font-size: 38px;
                color: #1a2b3c;
                margin-bottom: 8px;
                font-weight: 600;
            }
            
            .hero p {
                color: #666;
                font-size: 17px;
                font-style: italic;
            }
            
            .editor-panel {
                background: #f8f9fa;
                border-radius: 10px;
                padding: 25px;
                margin-bottom: 25px;
                border: 1px solid #dee2e6;
                box-shadow: inset 0 1px 3px rgba(0,0,0,0.05);
            }
            
            .editor-panel h3 {
                color: #1a2b3c;
                margin-bottom: 18px;
                font-size: 20px;
                font-weight: 500;
                display: flex;
                align-items: center;
            }
            
            .editor-panel h3:before {
                content: '►';
                color: #ff6b35;
                margin-right: 8px;
                font-size: 18px;
            }
            
            .input-group {
                margin-bottom: 20px;
            }
            
            .input-group label {
                display: block;
                margin-bottom: 6px;
                color: #2c3e50;
                font-weight: 500;
                font-size: 14px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }
            
            .input-group input {
                width: 100%;
                padding: 14px 16px;
                border: 2px solid #dce4ec;
                border-radius: 8px;
                font-size: 15px;
                font-family: 'Courier New', monospace;
                background: white;
                transition: border 0.2s;
            }
            
            .input-group input:focus {
                border-color: #ff6b35;
                outline: none;
                box-shadow: 0 0 0 3px rgba(255,107,53,0.1);
            }
            
            button {
                background: #ff6b35;
                color: white;
                border: none;
                padding: 14px 32px;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.2s;
                text-transform: uppercase;
                letter-spacing: 0.5px;
                border-bottom: 3px solid #cc4b1f;
            }
            
            button:hover {
                background: #ff5722;
                transform: translateY(-1px);
                border-bottom-width: 4px;
            }
            
            button:active {
                transform: translateY(2px);
                border-bottom-width: 1px;
            }
            
            .examples {
                margin-top: 30px;
            }
            
            .examples h4 {
                color: #1a2b3c;
                margin-bottom: 15px;
                font-size: 18px;
                font-weight: 500;
                border-left: 4px solid #ff6b35;
                padding-left: 12px;
            }
            
            .examples-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
                gap: 20px;
            }
            
            .example-card {
                background: white;
                border: 1px solid #e0e0e0;
                border-radius: 10px;
                padding: 18px;
                transition: all 0.2s;
                box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            }
            
            .example-card:hover {
                transform: translateY(-3px);
                box-shadow: 0 10px 25px rgba(0,0,0,0.1);
                border-color: #ff6b35;
            }
            
            .example-card h5 {
                color: #1a2b3c;
                margin-bottom: 10px;
                font-size: 17px;
                font-weight: 600;
            }
            
            .example-card p {
                color: #666;
                font-size: 14px;
                margin-bottom: 12px;
                line-height: 1.5;
            }
            
            .example-card code {
                background: #2d2d2d;
                color: #f8f8f8;
                padding: 8px 10px;
                border-radius: 6px;
                font-size: 13px;
                display: block;
                margin-bottom: 12px;
                font-family: 'Courier New', monospace;
                border-left: 3px solid #ff6b35;
            }
            
            .example-card .btn {
                display: inline-block;
                background: #1a2b3c;
                color: white;
                text-decoration: none;
                padding: 6px 15px;
                border-radius: 5px;
                font-size: 13px;
                font-weight: 500;
                transition: background 0.2s;
            }
            
            .example-card .btn:hover {
                background: #ff6b35;
            }
            
            .badge {
                background: #ff6b35;
                color: white;
                padding: 4px 10px;
                border-radius: 20px;
                font-size: 12px;
                font-weight: 600;
                margin-left: 10px;
                display: inline-block;
                text-transform: uppercase;
            }
            
            .footer {
                background: #f5f5f5;
                padding: 20px 30px;
                text-align: center;
                color: #666;
                border-top: 1px solid #ddd;
                font-size: 14px;
            }
            
            .warning {
                background: #fff3e0;
                border: 1px solid #ffe0b2;
                padding: 15px;
                border-radius: 8px;
                margin-top: 25px;
                color: #e65100;
                font-size: 14px;
                border-left: 4px solid #ff6b35;
            }
            
            .warning strong {
                color: #bf360c;
            }

            .screenshot-note {
                text-align: center;
                margin: 20px 0;
                font-size: 13px;
                color: #888;
                font-style: italic;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <div class="logo">Flask<span>Lab</span></div>
                <div class="nav">
                    <a href="/">Главная</a>
                    <a href="https://flask-russian-docs.readthedocs.io/ru/latest/" target="_blank">Документация</a>
                </div>
            </div>
            <div class="main">
                <div class="hero">
                    <h1>Лаборатория FLASK</h1>
                </div>               
                <div class="editor-panel">
                    <h3>Онлайн-компилятор Flask</h3> 
                    <form method="GET" action="/greet">
                        <div class="input-group">
                            <label>Введи пейлод:</label>
                            <input type="text" name="name" placeholder=" " value=" ">
                        </div>
                        <button type="submit">Выполнить</button>
                    </form>
                </div>
           
        </div>
    </body>
    </html>
    '''

@app.route('/greet')
def greet():
    name = request.args.get('name', 'гость')
    template = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Result</title>
        <style>
            body {{ 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
                margin: 0; 
                min-height: 100vh;
                background-image: url('https://avatars.mds.yandex.net/i?id=80c2a203e4bcd95e9ae1dc6a25ddca2e_l-8315541-images-thumbs&n=13');
                background-size: cover;
                background-position: center;
                background-attachment: fixed;
                position: relative;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
            }}
            
            body::before {{
                content: '';
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(255, 255, 255, 0.9);
                z-index: 0;
            }}
            
            .container {{ 
                background: white; 
                padding: 30px; 
                border-radius: 12px; 
                box-shadow: 0 20px 40px rgba(0,0,0,0.2);
                position: relative;
                z-index: 1;
                max-width: 800px;
                width: 100%;
                border: 1px solid rgba(0,0,0,0.1);
            }}
            
            h1 {{ 
                color: #1a2b3c; 
                margin-bottom: 20px;
                font-size: 28px;
                border-bottom: 2px solid #ff6b35;
                padding-bottom: 10px;
            }}
            
            .result {{ 
                background: #1a2b3c; 
                color: #ff6b35; 
                padding: 25px; 
                border-radius: 8px;
                font-family: 'Courier New', monospace; 
                white-space: pre-wrap;
                word-break: break-word;
                font-size: 15px;
                border: 1px solid #2c3e50;
                box-shadow: inset 0 2px 5px rgba(0,0,0,0.2);
                margin-bottom: 20px;
            }}
            
            a {{ 
                color: #ff6b35; 
                text-decoration: none;
                font-weight: 500;
                padding: 8px 16px;
                border: 2px solid #ff6b35;
                border-radius: 6px;
                display: inline-block;
                transition: all 0.2s;
            }}
            
            a:hover {{ 
                background: #ff6b35;
                color: white;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Результат выполнения:</h1>
            <div class="result">{name}</div>
            <a href="/">Вернуться на главную</a>
        </div>
    </body>
    </html>
    '''
    
    return render_template_string(template)

@app.route('/debug')
def debug():
    try:
        files = os.listdir('flags') if os.path.exists('flags') else []
        return jsonify({
            'status': 'ok',
            'flags_count': len(files),
            'flags_files': files,
            'server': 'Flask'
        })
    except:
        return jsonify({'error': 'debug error'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3003, debug=True)